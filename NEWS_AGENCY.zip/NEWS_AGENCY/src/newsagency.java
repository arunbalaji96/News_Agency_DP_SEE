import java.util.List;
import java.util.Scanner;

public class newsagency 
{
	public static void main(String args[])
	
	String report,name;        
	String[] category={"AA" , "BB" , "CC" , "DD" , "EE"};
	Scanner in=new Scanner(System.in);
	doit :
	System.out.println("Enter 1 for Reporter  2 for Reader ");
	int choice = in.nextInt();
	     
           if(choice==1)
           {
        	   
        	   System.out.println("Do you want to write a report ? 1.Yes 2.no");
               choice = in.nextInt();
        	   if(choice==1)
        	   {   
        		 
        		   System.out.println("Enter Your Category.AA / BB / CC / DD / EE ?");
        		   category= in.next();   
        	       System.out.println("Enter news report :");
        	       report=in.next();
        	       }
        	   else
        	   {
        		   logout();
        	   }
           } 
        	else
        	{    
        		
        		      		
        		System.out.println("Enter Your name.");
        		name=in.next();
        			reader normreader1 = new reader(name , category);
        			reader normreader2 = new reader(name ,category);
        		    reader normreader3 = new reader(name , category);
        		    readerPrim preReader1 = new readerPrim(name , category);
        		    readerPrim preReader2 =  new readerPrim(name , category);
        		
        		
        				
        	}   
	continue doit;}
   
  public static void logout()
  {
	  continue doit;
  }
      	   

}



