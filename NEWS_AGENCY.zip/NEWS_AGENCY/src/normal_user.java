
public class normal_user implements reader
{
	private String name ; String[] sbc = new String[6]; String[] category = String[6];
    
	
	public normal_user(String name , String category )	
   {
	this.name=name; this.category = category;
		
   }

public void subscribe()
{
System.out.println("Normal user , Enter your subscriptions. AA/BB/CC/DD/EE");
for(int i=0;i<2;i++)
	String sbc = in.next();
    subscription.add(sbc);
    for(int j=0;j<5;j++)
	{  
	if(subscription[i] == category[j])
	System.out.println(report);
	else
		System.out.println("No news");
	}
    
    
 public void addsubs()
 {
	 full :
	 if(subscription.length = 2)
		 System.out.println("No.of subscriptions is full. To add new , delete any current subscrition");
	 else
	 {  
		 int len = subscription.length;
		System.out.println("Enter your subscription . AA/BB/CC/DD/EE");
		for(int i=0;i<=len)
		{		String s=in.next();
			subscription[i]= s;
     	 }
		 goto full;
	 }
 }
    
  public void delsubs()
  {
	 for(int i=0;i<subscription.length;i++)
	 { System.out.println("Your subs : subscription[i]");}
	   
	 System.out.println("What do u want to unsubscribe ?");
	   String unsub = in.next();
	   for(int i=0; i<subscription.length;i++)
		   {if(unsub == subscription[i])
			   subscription[i]=NULL;
		   else
			   subscription[i]=subscription[i];}
	 
  }
    
    
    
}
  
}
