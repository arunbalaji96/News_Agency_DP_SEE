
public class observer {
	public agency;
	public reader;
	public normal_user;
	

}
