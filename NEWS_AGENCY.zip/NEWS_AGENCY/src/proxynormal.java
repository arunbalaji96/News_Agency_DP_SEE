
public class proxynormal implements reader{
	

}
