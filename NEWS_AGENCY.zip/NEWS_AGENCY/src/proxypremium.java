
public class proxypremium {

}
