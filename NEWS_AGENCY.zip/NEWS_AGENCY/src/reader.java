
public interface reader {
	 public void create();
	 abstract void subscribe();
	 public void addsubs();
	 public void delsubs();
	 

}
