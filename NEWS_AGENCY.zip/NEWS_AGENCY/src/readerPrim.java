
public interface readerPrim {
	abstract void subscribe();
	 public void addsubs();
	 public void delsubs();

}
